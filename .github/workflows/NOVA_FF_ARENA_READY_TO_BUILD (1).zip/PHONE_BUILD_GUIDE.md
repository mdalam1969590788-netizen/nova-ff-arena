# NOVA FF ARENA — ফোন দিয়ে APK বানানোর গাইড (Phone-only)

এই ZIP সোর্স কোড। সরাসরি ইনস্টল করা যায় না। নিচের ধাপগুলো ফলো করলে GitHub দিয়ে APK বানাতে পারবেন।

## ধাপ ১: GitHub অ্যাকাউন্ট
1. https://github.com এ গিয়ে সাইন আপ / লগইন করুন।
2. নতুন রিপোজিটরি তৈরি করুন (New repository)।
   - নাম: `nova-ff-arena` (যেকোনো নাম দিতে পারেন)
   - Public রাখুন (ফ্রি Actions এর জন্য সুবিধাজনক)
   - **README / .gitignore / license যোগ করবেন না** (খালি রিপো)

## ধাপ ২: কোড আপলোড
### মোবাইল (Chrome) দিয়ে:
1. এই ফোল্ডারের **সব ফাইল** (NOVA_FF_ARENA_FINAL এর ভিতরের জিনিস) আপলোড করুন।
2. অথবা কম্পিউটার থেকে:
   ```bash
   git init
   git add .
   git commit -m "Initial NOVA FF Arena"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/nova-ff-arena.git
   git push -u origin main
   ```

**গুরুত্বপূর্ণ:** `NOVA_FF_ARENA_FINAL` ফোল্ডারের **ভিতরের** ফাইলগুলো রিপোর রুটে থাকতে হবে (`pubspec.yaml` সরাসরি দেখা যাবে)।

## ধাপ ৩: Actions চালানো
1. রিপোতে যান → **Actions** ট্যাব।
2. বাম পাশে **Build Android APK** সিলেক্ট করুন।
3. **Run workflow** → **Run workflow** বাটন চাপুন।
4. ৫–১৫ মিনিট অপেক্ষা করুন (সবুজ টিক আসলে সফল)।

## ধাপ ৪: APK ডাউনলোড ও ইনস্টল
1. সফল রানের উপর ক্লিক করুন।
2. নিচে **Artifacts** সেকশনে `nova-ff-arena-debug-apk` দেখবেন।
3. ডাউনলোড করুন → আনজিপ করুন → `app-debug.apk` পাবেন।
4. ফোনে **Unknown sources / Install unknown apps** অন করে APK ইনস্টল করুন।

## (ঐচ্ছিক) Supabase কানেক্ট
ব্যাকএন্ড লাগলে:
1. https://supabase.com এ প্রজেক্ট খুলুন।
2. SQL Editor এ `supabase/schema.sql` (এবং প্রয়োজনমতো wallet/admin schema) রান করুন।
3. GitHub রিপো → **Settings** → **Secrets and variables** → **Actions**
4. দুইটা secret যোগ করুন:
   - `SUPABASE_URL` = আপনার project URL
   - `SUPABASE_ANON_KEY` = anon / publishable key  
   **কখনো service_role key দেবেন না।**

Secret যোগ করার পর আবার **Run workflow** চালান।

## সমস্যা হলে
- Build fail → Actions লগ পড়ুন (সাধারণত dependency বা Flutter ভার্সন)।
- APK ইনস্টল হয় না → ফোনের “Install unknown apps” পারমিশন দিন।
- সাদা স্ক্রিন / ক্র্যাশ → Supabase secret ভুল থাকতে পারে; secret ছাড়াও demo মোডে চলার কথা।

## পরবর্তী (প্রোডাকশন)
- Release keystore + Play App Signing
- আসল bKash/Nagad মার্চেন্ট সেটআপ (সার্ভার সাইড)
- Email/Phone verification চালু
