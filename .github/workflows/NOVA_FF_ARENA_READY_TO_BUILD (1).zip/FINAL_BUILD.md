# NOVA FF ARENA — Final Android Source Package

This package consolidates the latest cumulative implementation and Android build configuration.

## Compatibility
- Android applicationId: `com.novaffarena.nfa`
- Minimum Android SDK: 23 (Android 6.0 / Marshmallow)
- Target/compile SDK are delegated to the installed Flutter SDK in the build environment.
- This is designed for a broad range of Android phones, but no Android app can honestly guarantee compatibility with every device/model/OS.

## Cloud build
The repository contains `.github/workflows/android-apk.yml` for GitHub Actions.

Before production use:
- Configure Supabase URL/anon key as GitHub secrets/build-time defines as appropriate.
- Apply Supabase SQL migrations to the intended project.
- Configure release signing / Play App Signing.
- Add official payment-provider credentials only on the server side.

## Verification limitation
This environment does not contain Flutter/Dart SDK, Android SDK, or an emulator. Therefore no claim is made that `flutter analyze`, `flutter test`, or an APK build was executed here.
