package com.novaffarena.nfa

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
