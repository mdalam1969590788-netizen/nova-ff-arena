// Phase 9: authenticated status read boundary.
// This endpoint reports the server-stored intent state; it does not trust a
// client-provided payment success flag.
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'GET') return json({ error: 'method_not_allowed' }, 405);

  const authHeader = req.headers.get('Authorization');
  const id = new URL(req.url).searchParams.get('id');
  if (!authHeader || !id) return json({ error: 'authorization_and_id_required' }, 400);

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_ANON_KEY')!,
      { global: { headers: { Authorization: authHeader } } },
    );
    const { data: userData, error: userError } = await supabase.auth.getUser();
    if (userError || !userData.user) return json({ error: 'unauthorized' }, 401);

    const { data, error } = await supabase
      .from('payment_intents')
      .select('id,provider,amount,status,provider_reference,created_at,updated_at,verified_at,expires_at')
      .eq('id', id)
      .eq('user_id', userData.user.id)
      .maybeSingle();

    if (error) return json({ error: 'status_lookup_failed' }, 500);
    if (!data) return json({ error: 'not_found' }, 404);
    return json({ intent: data });
  } catch (_) {
    return json({ error: 'server_error' }, 500);
  }
});

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}
