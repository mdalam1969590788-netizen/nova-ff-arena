// Phase 9 trusted backend boundary.
// Provider-specific checkout calls are deliberately not invented here.
// Configure the approved provider adapter only after official onboarding.
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, idempotency-key',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'method_not_allowed' }, 405);

  const authHeader = req.headers.get('Authorization');
  const idempotencyKey = req.headers.get('Idempotency-Key')?.trim();
  if (!authHeader || !idempotencyKey) {
    return json({ error: 'authorization_and_idempotency_key_required' }, 400);
  }

  try {
    const body = await req.json();
    const provider = String(body.provider ?? '');
    const amount = Number(body.amount);
    if (!Number.isSafeInteger(amount) || amount <= 0) {
      return json({ error: 'invalid_amount' }, 400);
    }
    if (idempotencyKey.length < 16 || idempotencyKey.length > 128) {
      return json({ error: 'invalid_idempotency_key' }, 400);
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_ANON_KEY')!,
      { global: { headers: { Authorization: authHeader } } },
    );

    const { data: userData, error: userError } = await supabase.auth.getUser();
    if (userError || !userData.user) return json({ error: 'unauthorized' }, 401);

    const { data, error } = await supabase.rpc('create_payment_intent', {
      p_provider: provider,
      p_amount: amount,
      p_idempotency_key: idempotencyKey,
    });
    if (error) return json({ error: 'payment_intent_creation_failed' }, 400);

    // Provider checkout must be attached by a trusted, approved adapter.
    // Never accept checkout URL, success status, provider reference, or amount
    // from the client as proof of payment.
    return json({ intent: data, next_step: 'provider_adapter_required' });
  } catch (_) {
    return json({ error: 'invalid_request' }, 400);
  }
});

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}
