-- NOVA FF ARENA Phase 6
-- Review and adapt before applying in production.

create table if not exists public.admin_roles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('admin', 'moderator')),
  created_at timestamptz not null default now()
);

alter table public.admin_roles enable row level security;

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.admin_roles
    where user_id = auth.uid()
      and role = 'admin'
  );
$$;

revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;

-- Add admin-only policies to matches, results, and moderation tables
-- after reviewing your schema. Do not trust a client-side admin flag.
-- Production admin actions should also create immutable audit-log records.
