-- NOVA FF ARENA Phase 3 schema
-- Run in Supabase SQL editor. This schema deliberately keeps wallet/payment out of Phase 3.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique,
  phone text unique,
  avatar_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.matches (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  mode text not null check (mode in ('BR Solo','BR Duo','BR Squad','CS 4V4')),
  starts_at timestamptz not null,
  total_slots integer not null check (total_slots > 0),
  entry_fee integer not null default 0 check (entry_fee >= 0),
  prize integer not null default 0 check (prize >= 0),
  status text not null default 'upcoming' check (status in ('upcoming','live','completed')),
  rules text not null default 'No emulator • No hacks • Fair play only.',
  room_id text,
  room_password text,
  created_at timestamptz not null default now()
);

create table if not exists public.match_slots (
  id bigint generated always as identity primary key,
  match_id uuid not null references public.matches(id) on delete cascade,
  slot_number integer not null,
  user_id uuid references auth.users(id) on delete set null,
  reserved_at timestamptz,
  unique(match_id, slot_number),
  unique(match_id, user_id)
);

create index if not exists match_slots_match_id_idx on public.match_slots(match_id);
create index if not exists match_slots_user_id_idx on public.match_slots(user_id);

alter table public.profiles enable row level security;
alter table public.matches enable row level security;
alter table public.match_slots enable row level security;

create policy "profiles are viewable by authenticated users" on public.profiles
for select to authenticated using (true);
create policy "users can insert own profile" on public.profiles
for insert to authenticated with check (id = auth.uid());
create policy "users can update own profile" on public.profiles
for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

create policy "authenticated users can view matches" on public.matches
for select to authenticated using (true);
create policy "users can view slot occupancy" on public.match_slots
for select to authenticated using (true);

-- Atomic slot claim. The unique constraints prevent duplicate claims even under concurrent requests.
create or replace function public.claim_match_slot(p_match_id uuid, p_slot_number integer)
returns public.match_slots
language plpgsql
security invoker
set search_path = public
as $$
declare
  claimed public.match_slots;
  m public.matches;
begin
  if auth.uid() is null then
    raise exception 'AUTH_REQUIRED';
  end if;

  select * into m from public.matches where id = p_match_id for update;
  if not found then raise exception 'MATCH_NOT_FOUND'; end if;
  if m.status <> 'upcoming' then raise exception 'MATCH_NOT_OPEN'; end if;
  if p_slot_number < 1 or p_slot_number > m.total_slots then raise exception 'INVALID_SLOT'; end if;

  insert into public.match_slots(match_id, slot_number, user_id, reserved_at)
  values (p_match_id, p_slot_number, auth.uid(), now())
  returning * into claimed;

  return claimed;
exception
  when unique_violation then
    raise exception 'SLOT_ALREADY_TAKEN';
end;
$$;

grant execute on function public.claim_match_slot(uuid, integer) to authenticated;
