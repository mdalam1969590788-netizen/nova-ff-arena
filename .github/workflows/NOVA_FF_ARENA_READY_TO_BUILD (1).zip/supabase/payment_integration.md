# NOVA FF ARENA — Phase 8 payment integration

## Current phase status

The Flutter payment contract now supports:

- createPayment()
- verifyPayment()
- getPaymentStatus()
- refundPayment()

The bKash and Nagad adapters intentionally contain no merchant credentials and do
not call provider APIs directly. They are waiting for a trusted backend adapter
configured with an officially approved merchant/gateway account.

A non-money-moving SandboxPaymentProvider exists for application/integration tests.
It never credits the NFA wallet.

## Required production flow

Flutter
  -> authenticated Supabase Edge Function
  -> provider adapter
  -> provider checkout
  -> provider callback/webhook
  -> server-side verification
  -> idempotent wallet ledger write
  -> wallet balance projection

### Security invariants

1. Never ship provider secrets, private keys, service-role keys, merchant passwords,
   PINs or OTP handling logic in Flutter.
2. The client cannot mark a transaction successful.
3. Amount, user identity and transaction state are verified on the server.
4. `idempotency_key` and `provider_reference` prevent duplicate credits.
5. Wallet mutations happen only in trusted server-side code.
6. Provider callbacks are authenticated/validated according to the provider's
   current official documentation.
7. Log transaction IDs and safe metadata, never secrets or payment credentials.
8. Handle pending, success, failed, cancelled and expired states.
9. Refunds are server-side and auditable.
10. Keep paid entry, deposits and withdrawals disabled until provider approval,
    backend verification and applicable Bangladesh compliance requirements are
    confirmed.

## Required backend secrets

Store these only in the Supabase Edge Function secret manager/environment:

BKASH_BASE_URL=
BKASH_APP_KEY=
BKASH_APP_SECRET=
BKASH_USERNAME=
BKASH_PASSWORD=

NAGAD_BASE_URL=
NAGAD_MERCHANT_ID=
NAGAD_PRIVATE_KEY=

Do not invent endpoint paths or credentials. Use the current official provider
merchant/API documentation supplied for the approved account.

## Sandbox gate

The NFA app may exercise the SandboxPaymentProvider for UI and integration tests,
but a sandbox result must never be written as a real successful wallet credit.
