-- NOVA FF ARENA Phase 8 migration
-- Bug reports + payment idempotency foundation.
-- Review in the target Supabase project before applying to production.

create type public.bug_report_severity as enum ('low', 'medium', 'high', 'critical');
create type public.bug_report_status as enum ('open', 'in_progress', 'resolved', 'closed');

create table if not exists public.bug_reports (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(trim(title)) between 4 and 100),
  description text not null check (char_length(trim(description)) between 10 and 3000),
  severity public.bug_report_severity not null default 'medium',
  status public.bug_report_status not null default 'open',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists bug_reports_user_created_idx
  on public.bug_reports(user_id, created_at desc);

alter table public.bug_reports enable row level security;

drop policy if exists "Users can create own bug reports" on public.bug_reports;
create policy "Users can create own bug reports"
on public.bug_reports
for insert
to authenticated
with check (auth.uid() = user_id);

drop policy if exists "Users can read own bug reports" on public.bug_reports;
create policy "Users can read own bug reports"
on public.bug_reports
for select
to authenticated
using (auth.uid() = user_id);

-- Admin reads/updates must be performed through server-authorized policies/functions.
-- Do not add a policy based on a client-supplied role.

-- Payment idempotency fields. The wallet transaction row remains the ledger record.
alter table public.wallet_transactions
  add column if not exists idempotency_key text;

create unique index if not exists wallet_transactions_idempotency_key_uq
  on public.wallet_transactions(idempotency_key)
  where idempotency_key is not null;

create unique index if not exists wallet_transactions_provider_reference_uq
  on public.wallet_transactions(provider_reference)
  where provider_reference is not null;

-- The client must not insert/update wallet_transactions.
-- A trusted backend function should:
-- 1) authenticate the user;
-- 2) create/reuse the transaction by idempotency_key;
-- 3) create provider checkout;
-- 4) verify provider callback/status server-side;
-- 5) update the ledger exactly once;
-- 6) record verified_at;
-- 7) never accept a client-supplied "success" status.
