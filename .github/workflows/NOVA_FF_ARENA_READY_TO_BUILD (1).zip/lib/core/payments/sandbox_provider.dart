import 'payment_provider.dart';

/// Explicitly non-production provider used for UI/integration testing.
/// It does not move money or change the wallet ledger.
class SandboxPaymentProvider implements PaymentProvider {
  @override
  PaymentProviderType get type => PaymentProviderType.sandbox;

  @override
  Future<PaymentSession> createPayment(PaymentRequest request) async {
    if (request.amount <= 0) {
      throw ArgumentError.value(request.amount, 'amount', 'Must be positive.');
    }
    return PaymentSession(
      checkoutUrl: 'https://sandbox.invalid/nfa-checkout',
      providerReference: 'SANDBOX-${request.idempotencyKey}',
    );
  }

  @override
  Future<PaymentStatus> verifyPayment(String transactionId) async {
    return PaymentStatus(
      transactionId: transactionId,
      state: PaymentTransactionState.pending,
      amount: 0,
    );
  }

  @override
  Future<PaymentStatus> getPaymentStatus(String transactionId) async {
    return PaymentStatus(
      transactionId: transactionId,
      state: PaymentTransactionState.pending,
      amount: 0,
    );
  }

  @override
  Future<void> refundPayment({
    required String transactionId,
    required String reason,
  }) async {
    // Sandbox only: no real transaction exists to refund.
  }
}
