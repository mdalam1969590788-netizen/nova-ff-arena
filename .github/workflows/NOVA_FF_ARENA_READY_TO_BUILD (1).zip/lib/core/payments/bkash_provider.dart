import 'payment_provider.dart';

/// Client adapter for the trusted NFA backend.
/// Provider credentials and verification remain server-side.
class BkashProvider implements PaymentProvider {
  @override
  PaymentProviderType get type => PaymentProviderType.bkash;

  @override
  Future<PaymentSession> createPayment(PaymentRequest request) {
    throw UnimplementedError(
      'Connect to the NFA backend Edge Function for approved bKash checkout.',
    );
  }

  @override
  Future<PaymentStatus> verifyPayment(String transactionId) {
    throw UnimplementedError(
      'Payment verification must be performed by the trusted backend.',
    );
  }

  @override
  Future<PaymentStatus> getPaymentStatus(String transactionId) {
    throw UnimplementedError(
      'Payment status must be read from the trusted backend.',
    );
  }

  @override
  Future<void> refundPayment({
    required String transactionId,
    required String reason,
  }) {
    throw UnimplementedError(
      'Refunds must be initiated and verified by the trusted backend.',
    );
  }
}
