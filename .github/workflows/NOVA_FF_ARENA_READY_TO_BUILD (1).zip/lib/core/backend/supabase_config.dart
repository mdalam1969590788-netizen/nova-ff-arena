import 'package:flutter/foundation.dart';

/// Set these with --dart-define in a real build. Never commit service-role keys.
class SupabaseConfig {
  static const url = String.fromEnvironment('SUPABASE_URL');
  static const anonKey = String.fromEnvironment('SUPABASE_ANON_KEY');

  static bool get isConfigured => url.isNotEmpty && anonKey.isNotEmpty;

  static void assertConfigured() {
    if (!isConfigured) {
      throw StateError(
        'Supabase is not configured. Run with --dart-define=SUPABASE_URL=... '
        '--dart-define=SUPABASE_ANON_KEY=...',
      );
    }
    if (kDebugMode) debugPrint('NFA Supabase configuration loaded.');
  }
}
