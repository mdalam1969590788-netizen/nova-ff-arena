import 'package:flutter/material.dart';

abstract final class AppColors {
  static const background = Color(0xFF050509);
  static const background2 = Color(0xFF080A12);
  static const surface = Color(0xFF10121A);
  static const surfaceElevated = Color(0xFF151824);
  static const surface2 = Color(0xFF1B1E2A);
  static const primary = Color(0xFF2447FF);
  static const primaryDeep = Color(0xFF1429B8);
  static const neonBlue = Color(0xFF4D72FF);
  static const accent = Color(0xFF7D96FF);
  static const textPrimary = Colors.white;
  static const textSecondary = Color(0xFF969AAA);
  static const textMuted = Color(0xFF666B7A);
  static const border = Color(0xFF242837);
  static const borderGlow = Color(0xFF344B9B);
  static const success = Color(0xFF38D996);
  static const warning = Color(0xFFFFC857);
  static const danger = Color(0xFFFF5C72);
}
