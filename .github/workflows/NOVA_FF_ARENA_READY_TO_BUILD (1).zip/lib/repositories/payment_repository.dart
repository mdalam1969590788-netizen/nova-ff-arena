
import 'package:supabase_flutter/supabase_flutter.dart';

class PaymentIntent {
  final String id;
  final String provider;
  final int amount;
  final String status;
  final String? providerReference;
  final String? checkoutUrl;

  const PaymentIntent({
    required this.id,
    required this.provider,
    required this.amount,
    required this.status,
    this.providerReference,
    this.checkoutUrl,
  });

  factory PaymentIntent.fromMap(Map<String, dynamic> map) => PaymentIntent(
    id: map['id'] as String,
    provider: map['provider'] as String,
    amount: (map['amount'] as num).toInt(),
    status: map['status'] as String,
    providerReference: map['provider_reference'] as String?,
    checkoutUrl: map['checkout_url'] as String?,
  );
}

class PaymentRepository {
  PaymentRepository(this.client);
  final SupabaseClient client;

  Future<PaymentIntent> createSandboxIntent({
    required int amount,
    required String idempotencyKey,
  }) async {
    if (amount < 1 || amount > 100000000) {
      throw ArgumentError('Invalid amount.');
    }
    if (idempotencyKey.trim().length < 16) {
      throw ArgumentError('Invalid idempotency key.');
    }

    final result = await client.rpc('create_payment_intent', params: {
      'p_provider': 'sandbox',
      'p_amount': amount,
      'p_idempotency_key': idempotencyKey.trim(),
    });

    return PaymentIntent.fromMap(
      Map<String, dynamic>.from(result as Map),
    );
  }

  Future<PaymentIntent?> getIntent(String id) async {
    final row = await client
        .from('payment_intents')
        .select(
          'id,provider,amount,status,provider_reference,checkout_url',
        )
        .eq('id', id)
        .maybeSingle();

    return row == null
        ? null
        : PaymentIntent.fromMap(Map<String, dynamic>.from(row));
  }
}
