import 'package:supabase_flutter/supabase_flutter.dart';

class AuthRepository {
  AuthRepository(this.client);
  final SupabaseClient client;

  Stream<AuthState> get authStateChanges => client.auth.onAuthStateChange;
  User? get currentUser => client.auth.currentUser;

  Future<void> signUp({
    required String email,
    required String password,
    required String username,
    required String phone,
  }) async {
    final response = await client.auth.signUp(
      email: email.trim(),
      password: password,
      data: {'username': username.trim(), 'phone': phone.trim()},
    );
    if (response.user == null) {
      throw const AuthException('Account could not be created.');
    }
  }

  Future<void> signIn(String emailOrPhone, String password) async {
    final value = emailOrPhone.trim();
    if (value.contains('@')) {
      await client.auth.signInWithPassword(email: value, password: password);
      return;
    }
    // Phone login requires the phone-auth provider to be enabled in Supabase.
    await client.auth.signInWithPassword(phone: value, password: password);
  }

  Future<void> resetPassword(String email) =>
      client.auth.resetPasswordForEmail(email.trim());

  Future<void> signOut() => client.auth.signOut();
}
