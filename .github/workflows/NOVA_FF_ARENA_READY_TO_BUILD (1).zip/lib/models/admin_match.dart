enum AdminMatchStatus { draft, published, live, completed, cancelled }

class AdminMatch {
  final String id;
  final String title;
  final String mode;
  final int entryFee;
  final int prizePool;
  final int totalSlots;
  final int bookedSlots;
  final AdminMatchStatus status;

  const AdminMatch({
    required this.id,
    required this.title,
    required this.mode,
    required this.entryFee,
    required this.prizePool,
    required this.totalSlots,
    required this.bookedSlots,
    required this.status,
  });

  AdminMatch copyWith({
    String? title,
    String? mode,
    int? entryFee,
    int? prizePool,
    int? totalSlots,
    int? bookedSlots,
    AdminMatchStatus? status,
  }) {
    return AdminMatch(
      id: id,
      title: title ?? this.title,
      mode: mode ?? this.mode,
      entryFee: entryFee ?? this.entryFee,
      prizePool: prizePool ?? this.prizePool,
      totalSlots: totalSlots ?? this.totalSlots,
      bookedSlots: bookedSlots ?? this.bookedSlots,
      status: status ?? this.status,
    );
  }
}
