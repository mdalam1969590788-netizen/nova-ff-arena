import 'package:flutter/foundation.dart';

enum MatchStatus { upcoming, live, completed }

class TournamentMatch {
  const TournamentMatch({
    required this.id,
    required this.title,
    required this.mode,
    required this.dateTime,
    required this.totalSlots,
    required this.prize,
    required this.entryFee,
    required this.status,
    this.rules = 'No emulator • No hacks • Fair play only.',
    this.roomId,
    this.roomPassword,
    this.reservedSlots = const {},
  });
  final String id, title, mode;
  final DateTime dateTime;
  final int totalSlots, prize, entryFee;
  final MatchStatus status;
  final String rules;
  final String? roomId, roomPassword;
  final Set<int> reservedSlots;
  int get availableSlots => totalSlots - reservedSlots.length;
  TournamentMatch copyWith({Set<int>? reservedSlots}) => TournamentMatch(
    id: id, title: title, mode: mode, dateTime: dateTime, totalSlots: totalSlots,
    prize: prize, entryFee: entryFee, status: status, rules: rules,
    roomId: roomId, roomPassword: roomPassword,
    reservedSlots: reservedSlots ?? this.reservedSlots,
  );
}

class MatchStore extends ChangeNotifier {
  MatchStore() : matches = [
    TournamentMatch(id:'nfa-001', title:'NFA Night Clash #01', mode:'BR Squad', dateTime:DateTime.now().add(const Duration(hours:3)), totalSlots:48, prize:2000, entryFee:50, status:MatchStatus.upcoming, reservedSlots:{1,4,9,12,17,22,31,36}),
    TournamentMatch(id:'nfa-002', title:'NFA Solo Rush #07', mode:'BR Solo', dateTime:DateTime.now().add(const Duration(hours:7)), totalSlots:24, prize:1000, entryFee:30, status:MatchStatus.upcoming, reservedSlots:{2,5,7,15}),
    TournamentMatch(id:'nfa-003', title:'NFA CS Arena #03', mode:'CS 4V4', dateTime:DateTime.now().subtract(const Duration(minutes:15)), totalSlots:16, prize:1500, entryFee:60, status:MatchStatus.live, reservedSlots:{1,2,3,4,5,6,7,8,9,10,11,12}),
    TournamentMatch(id:'nfa-004', title:'NFA Duo Showdown #12', mode:'BR Duo', dateTime:DateTime.now().subtract(const Duration(days:1)), totalSlots:24, prize:1200, entryFee:40, status:MatchStatus.completed, reservedSlots:{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24}),
  ];
  final List<TournamentMatch> matches;
  final Set<String> myMatches = <String>{};
  bool join(String id, int slot) {
    final i=matches.indexWhere((m)=>m.id==id); if(i<0) return false;
    final m=matches[i];
    if(m.status!=MatchStatus.upcoming || slot<1 || slot>m.totalSlots || m.reservedSlots.contains(slot) || myMatches.contains(id)) return false;
    matches[i]=m.copyWith(reservedSlots:{...m.reservedSlots,slot}); myMatches.add(id); notifyListeners(); return true;
  }
}
