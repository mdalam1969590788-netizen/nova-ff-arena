
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../core/backend/backend.dart';
import '../../repositories/payment_repository.dart';

class SandboxDepositScreen extends StatefulWidget {
  const SandboxDepositScreen({super.key});
  static const routeName = '/wallet/sandbox-deposit';

  @override
  State<SandboxDepositScreen> createState() => _SandboxDepositScreenState();
}

class _SandboxDepositScreenState extends State<SandboxDepositScreen> {
  final _amount = TextEditingController();
  bool _busy = false;
  String? _message;

  @override
  void dispose() {
    _amount.dispose();
    super.dispose();
  }

  String _newIdempotencyKey() =>
      'nfa_${DateTime.now().microsecondsSinceEpoch}_${Object().hashCode}';

  Future<void> _createIntent() async {
    final amount = int.tryParse(_amount.text.trim());
    if (amount == null || amount < 10 || amount > 100000) {
      setState(() => _message = 'Enter a sandbox amount between ৳10 and ৳100,000.');
      return;
    }
    if (_busy) return;
    setState(() {
      _busy = true;
      _message = null;
    });

    try {
      final intent = await PaymentRepository(Backend.client).createSandboxIntent(
        amount: amount,
        idempotencyKey: _newIdempotencyKey(),
      );
      if (!mounted) return;
      setState(() {
        _message =
            'Test payment intent created: ${intent.id}\nStatus: ${intent.status}\n'
            'No wallet balance was credited.';
      });
    } on PostgrestException catch (e) {
      setState(() => _message = e.message);
    } on AuthException catch (e) {
      setState(() => _message = e.message);
    } catch (_) {
      setState(() => _message = 'Could not create the test payment. Try again.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('SANDBOX DEPOSIT')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Card(
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              'TEST MODE ONLY\n\nThis creates a server-side payment intent. '
              'It does not add money to your wallet and is not a real payment.',
            ),
          ),
        ),
        const SizedBox(height: 18),
        TextField(
          controller: _amount,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(
            labelText: 'Test amount',
            prefixText: '৳ ',
          ),
        ),
        const SizedBox(height: 14),
        FilledButton(
          onPressed: _busy ? null : _createIntent,
          child: Text(_busy ? 'CREATING...' : 'CREATE TEST PAYMENT'),
        ),
        if (_message != null) ...[
          const SizedBox(height: 16),
          Card(child: Padding(
            padding: const EdgeInsets.all(16),
            child: Text(_message!),
          )),
        ],
      ],
    ),
  );
}
