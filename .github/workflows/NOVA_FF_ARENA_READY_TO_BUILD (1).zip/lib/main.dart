import 'package:flutter/material.dart';

import 'app.dart';
import 'core/backend/backend.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Backend.initialize();
  runApp(const NovaFfArenaApp());
}
