from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# Bug-report flow was replaced by the lightweight Feedback screen.
assert (ROOT / "lib/screens/support/feedback_screen.dart").exists()
assert not (ROOT / "lib/screens/support/bug_report_screen.dart").exists()
assert not (ROOT / "lib/screens/admin/admin_bug_reports_screen.dart").exists()

print("PHASE 10 STATIC CHECKS: PASS")
